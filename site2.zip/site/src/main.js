// كود تفعيل زر المشاركة
window.sharePage = async () => {
  const shareData = {
    title: 'Azizos | حساباتي',
    text: 'تصفح جميع حساباتي الاجتماعية من خلال هذا الرابط!',
    url: window.location.href, // يأخذ رابط الموقع الحالي
  };

  try {
    if (navigator.share) {
      // إذا كان المتصفح يدعم المشاركة (مثل متصفحات الهواتف)
      await navigator.share(shareData);
    } else {
      // إذا لم يكن يدعم، يقوم بنسخ الرابط
      await navigator.clipboard.writeText(window.location.href);
      alert('تم نسخ رابط الموقع بنجاح!');
    }
  } catch (err) {
    console.log('حدث خطأ أثناء المشاركة:', err);
  }
};